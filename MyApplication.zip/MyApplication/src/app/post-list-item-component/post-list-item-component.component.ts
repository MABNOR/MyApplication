import { Component, OnInit, Input } from '@angular/core';
import { PostsService } from '../services/posts.service';
import {Post} from '../models/post.model';

@Component({
  selector: 'app-post-list-item-component',
  templateUrl: './post-list-item-component.component.html',
  styleUrls: ['./post-list-item-component.component.scss']
})

export class PostListItemComponentComponent implements OnInit {
  @Input() post: Post;
  constructor(private postsService: PostsService) { }

  ngOnInit() {
  }

  onLoveIt(post: Post) {
    this.postsService.LovePost(post);
  }

  onHateIt(post: Post) {
    this.postsService.HatePost(post);
  }

  getColor(post: Post) {
    if (post.loveIts > 0)
      return '#00FF30';
    else if (post.loveIts < 0)
      return '#EA6644';
    else if (post.loveIts === 0)
      return 'white' ;
  }

  onDeletePost(post: Post) {
    this.postsService.removePost(post);
  }

}
