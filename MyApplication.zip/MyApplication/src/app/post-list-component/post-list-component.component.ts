import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { PostsService } from '../services/posts.service';
import { Post } from '../models/post.model';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-list-component',
  templateUrl: './post-list-component.component.html',
  styleUrls: ['./post-list-component.component.scss']
})

export class PostListComponentComponent implements OnInit, OnDestroy {
  titre = 'Mon-blog';

  posts: Post[];
  postSubscription: Subscription;


  constructor(private postsService: PostsService, private router: Router) { }

  ngOnInit() {
    this.postSubscription = this.postsService.postSubject.subscribe(
      (posts: Post[]) => {
        this.posts = posts;
      }
    );
    this.postsService.getPosts();
    }


  onNewPost() {
    this.router.navigate(['/posts', 'new']);
  }


  ngOnDestroy() {
    this.postSubscription.unsubscribe();
  }
}
