import { Component } from '@angular/core';
import * as firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})



export class AppComponent {
  constructor() {
    var firebaseConfig = {
      apiKey: "AIzaSyCuqsN81FJWXNRVROtevyw9RWsblrJq2bI",
      authDomain: "my-blog-94762.firebaseapp.com",
      databaseURL: "https://my-blog-94762.firebaseio.com",
      projectId: "my-blog-94762",
      storageBucket: "",
      messagingSenderId: "853782775639",
      appId: "1:853782775639:web:714e082b3685a1e1"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
  }

}
