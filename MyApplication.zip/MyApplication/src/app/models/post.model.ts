export class Post {
  loveIts = 0 ;
  CreateDate = Date();
   constructor(public title: string , public content: string) {}
}
